#adicionando a funcao para inverter textos
def inverter(texto):
    return texto[::-1]
#testando a funcao
print(inverter("Vamos codar!"))
print(inverter("Precisaremos de um bom motivo para usar isso!"))